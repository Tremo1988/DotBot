import json
from pathlib import Path

"""main.py – trading automatico su DOT/USDC con logica corretta."""
import logging, sys, time, datetime
import pandas as pd, pandas_ta as ta
from modules.data_fetcher import get_binance_connection, fetch_ohlcv
from modules.sentiment import get_reddit_sentiment
from modules.indicator_utils import add_indicators, compute_trend, naive_forecast
from modules.trade_manager import TradeManager
from modules.telegram_notifier import send as tg_send

config = json.loads(Path("config.json").read_text(encoding="utf-8"))
SYMBOL = "DOT/USDC"
TIMEFRAME = "30m"
LIMIT = 500
LOOP_SECONDS = 1800
RSI_LEN = 14
LOGFILE = "bot_log.txt"

def ensure(df):
    if 'RSI' not in df.columns:
        df['RSI'] = ta.rsi(df['close'], length=RSI_LEN)
    return add_indicators(df)

def write_compact_line(text):
    with open(LOGFILE, "a", encoding="utf-8") as f:
        f.write(text + "\n")

def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s: %(message)s")
    ex = get_binance_connection()
    try:
        bal = ex.fetch_balance()
        dot_balance = bal.get('free', {}).get('DOT', 0) or bal.get('total', {}).get('DOT', 0)
    except Exception as cred_exc:
        logging.warning('No Binance credentials or fetch_balance failed – paper mode: %s', cred_exc)
        dot_balance = 0
    tm = TradeManager(config, dot_balance)
    tg_send(f"🤖 Avviato su {SYMBOL} ({TIMEFRAME})")

    while True:
        try:
            df = fetch_ohlcv(ex, SYMBOL, TIMEFRAME, LIMIT)
            df = ensure(df)

            price = df["close"].iloc[-1]
            rsi = df["RSI"].iloc[-1]
            macdh = df["MACDh"].iloc[-1]
            adx = df["ADX"].iloc[-1]
            atr = df["ATR"].iloc[-1]
            trend = compute_trend(df)
            forecast = naive_forecast(df)

            sentiment_r = get_reddit_sentiment(subreddit="Polkadot", )
            
            action = tm.evaluate(df, {
                'reddit': sentiment_r,
                'trend': trend
            }) or 'hold'
            if action != 'hold':
                tm.execute(action)
                tg_send(f"⚡️ Eseguita: {action.upper()}")
            else:
                tg_send('⏸️ HOLD – nessuna operazione')
            line = (f"{datetime.datetime.utcnow():%Y-%m-%d %H:%M:%S}, Price={price:.4f}, RSI={rsi:.2f}, "
                    f"MACDh={macdh:.4f}, Forecast={forecast:.4f}, Δ={forecast - price:.4f}, "
                    f"Sentiment=R{sentiment_r:.2f}, Price={price:.2f}, "
                    f"ADX={adx:.1f}, ATR={atr:.2f}, Trend={trend}, Action={action}")
            logging.info(line)
            tg_send(line)
            write_compact_line(line)

            time.sleep(LOOP_SECONDS)
        except KeyboardInterrupt:
            tg_send("🛑 Arrestato manualmente")
            break
        except Exception as exc:
            logging.exception("Errore nel ciclo: %s", exc)
            tg_send(f"❌ Errore: {exc}")
            time.sleep(30)

if __name__ == "__main__":
    main()