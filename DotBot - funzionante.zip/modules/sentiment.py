"""Sentiment da Reddit via public JSON API (no OAuth)."""
from __future__ import annotations
import logging, requests, json
from pathlib import Path
from typing import Any, List
from textblob import TextBlob

CONFIG_PATH = Path(__file__).resolve().parent.parent / "config.json"
_cfg: dict[str, Any] = {}
if CONFIG_PATH.exists():
    try:
        _cfg = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception:
        pass

DEFAULT_KEYWORDS: List[str] = _cfg.get("reddit_keywords", ["polkadot", "dot", "parachain"])
HEADERS = { "User-Agent": _cfg.get("reddit_user_agent", "DotBotSentiment/JSON 1.0") }

def _get_json(subreddit: str, query: str, limit: int = 100) -> list[dict[str, Any]]:
    url = (f"https://www.reddit.com/r/{subreddit}/search.json"
           f"?q={query}&restrict_sr=1&sort=new&limit={limit}")
    res = requests.get(url, headers=HEADERS, timeout=10)
    res.raise_for_status()
    data = res.json().get("data", {}).get("children", [])
    return [d.get("data", {}) for d in data]

def get_reddit_sentiment(subreddit: str = "Polkadot",
                         keywords: list[str] | None = None,
                         max_posts_per_kw: int = 100) -> float | None:
    """Polarity media (-1..+1) oppure None se nessun dato."""
    keywords = keywords or DEFAULT_KEYWORDS
    scores: list[float] = []
    for kw in keywords:
        try:
            submissions = _get_json(subreddit, kw, max_posts_per_kw)
            scores.extend([TextBlob(s.get('title','') + ' ' + (s.get('selftext') or '')).sentiment.polarity
                           for s in submissions])
        except requests.HTTPError as exc:
            logging.warning("Reddit JSON HTTP error (%s): %s", kw, exc)
        except Exception as exc:
            logging.warning("Reddit JSON error (%s): %s", kw, exc)
    if not scores:
        return None
    return sum(scores)/len(scores)
