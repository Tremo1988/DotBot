
"""Telegram notifier (sincrono) – non richiede python‑telegram‑bot.

Invia i messaggi con una semplice richiesta HTTPS all'endpoint Bot API,
evitando problemi di coroutine 'not awaited'.
"""

from __future__ import annotations
import os
import logging
import json
from pathlib import Path
from typing import Any

import requests

CONFIG_PATH = Path(__file__).resolve().parent.parent / "config.json"
_cfg: dict[str, Any] = {}
if CONFIG_PATH.exists():
    try:
        _cfg = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception:
        pass

_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN") or _cfg.get("telegram_bot_token")
_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID") or _cfg.get("telegram_chat_id")

def _api_url(method: str) -> str:
    return f"https://api.telegram.org/bot{_TOKEN}/{method}"

def send(message: str, parse_mode: str | None = None) -> None:
    """Invia *message* su Telegram se token e chat id sono configurati.

    Non solleva errori bloccanti: in caso di problemi scrive nel log.
    """
    if not _TOKEN or not _CHAT_ID:
        logging.debug("Telegram non configurato → %s", message)
        return

    data = {
        "chat_id": _CHAT_ID,
        "text": message,
    }
    if parse_mode:
        data["parse_mode"] = parse_mode
    try:
        resp = requests.post(_api_url("sendMessage"), json=data, timeout=10)
        if resp.status_code != 200:
            logging.warning(
                "Telegram API error %s: %s",
                resp.status_code,
                resp.text[:200],
            )
    except Exception as exc:  # pragma: no cover
        logging.exception("Errore HTTP Telegram: %s", exc)
