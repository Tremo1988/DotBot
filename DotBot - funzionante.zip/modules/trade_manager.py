import logging
from pathlib import Path
import csv
from datetime import datetime

class TradeManager:
    def __init__(self, config, dot_balance):
        self.config = config
        self.dot_balance = dot_balance
        self.base_amount = dot_balance * (config.get("sell_threshold_percent", 60) / 100)

    def evaluate(self, indicators, sentiment):
        rsi = indicators.get("rsi", 50)
        adx = indicators.get("adx", 0)
        macd = indicators.get("macd_hist", 0)

        if adx < self.config.get("min_adx_operativita", 20):
            return "hold"

        # Regole di acquisto progressivo
        if rsi < 30 and sentiment and sentiment > 0:
            if rsi < 20:
                return "buy_100"
            elif rsi < 25:
                return "buy_60"
            else:
                return "buy_30"

        # Regole di vendita progressiva
        if rsi > 70 and sentiment and sentiment < 0:
            if rsi > 80:
                return "sell_100"
            elif rsi > 75:
                return "sell_60"
            else:
                return "sell_30"

        return "hold"

    def execute(self, action, last_price, indicators, sentiment):
        amount = 0
        dot_balance = self.dot_balance
        min_to_sell = self.config.get("min_dot_to_sell", 0.5)

        if "buy" in action:
            pct = int(action.split("_")[1])
            amount = round((self.base_amount * pct / 100), 3)
            self.dot_balance += amount
            log_action = "buy"
        elif "sell" in action:
            pct = int(action.split("_")[1])
            sellable = min(dot_balance, self.base_amount * pct / 100)
            if sellable < min_to_sell:
                logging.info(f"⛔ Vendita annullata: {sellable} DOT < soglia minima {min_to_sell}")
                return
            amount = round(sellable, 3)
            self.dot_balance -= amount
            log_action = "sell"
        else:
            return

        # Logging CSV
        log_file = Path("trade_log.csv")
        log_exists = log_file.exists()
        with log_file.open("a", newline="") as f:
            writer = csv.writer(f)
            if not log_exists:
                writer.writerow(["timestamp", "action", "amount", "price", "rsi", "sentiment", "forecast"])
            writer.writerow([
                datetime.utcnow().isoformat(), log_action, amount, last_price,
                indicators.get("rsi", "NA"), sentiment, indicators.get("forecast_price", "NA")
            ])

        logging.info(f"✅ Eseguito {log_action.upper()} {amount} DOT @ ${last_price:.3f}")