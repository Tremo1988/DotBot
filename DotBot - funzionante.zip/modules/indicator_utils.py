
"""Indicator utilities – MACD columns renamed for easy access."""
import pandas as pd
import pandas_ta as ta

def add_indicators(df: pd.DataFrame) -> pd.DataFrame:
    # MACD
    macd = ta.macd(df['close'], fast=12, slow=26, signal=9)
    macd.columns = ['MACD', 'MACDh', 'MACDs']
    for col in macd.columns:
        df[col] = macd[col]

    # ADX
    adx = ta.adx(df['high'], df['low'], df['close'], length=14)
    df['ADX'] = adx['ADX_14']

    # ATR
    df['ATR'] = ta.atr(df['high'], df['low'], df['close'], length=14)
    return df

def compute_trend(df: pd.DataFrame) -> str:
    """Ritorna 'bullish', 'bearish' o 'sideways' in funzione della SMA 50."""
    sma = ta.sma(df['close'], length=50)
    if sma.isna().iloc[-1]:
        return 'sideways'
    price_now = df['close'].iloc[-1]
    threshold = 0.002  # 0.2 %
    if price_now > sma.iloc[-1] * (1 + threshold):
        return 'bullish'
    if price_now < sma.iloc[-1] * (1 - threshold):
        return 'bearish'
    return 'sideways'
    if df['close'].iloc[-1] > sma.iloc[-1] * 1.002:
        return 'bullish'
    elif df['close'].iloc[-1] < sma.iloc[-1] * 0.998:
        return 'bearish'
    return 'sideways'

def naive_forecast(df: pd.DataFrame) -> float:
    last_close = df['close'].iloc[-1]
    hist = df['MACDh'].iloc[-1]
    atr = df['ATR'].iloc[-1]
    direction = 1 if hist > 0 else -1 if hist < 0 else 0
    return last_close + direction * atr / 2
