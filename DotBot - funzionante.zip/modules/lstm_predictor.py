# ───────── modules/lstm_predictor.py ──────────
# Compatibile TensorFlow 2.13 – input shape (1, 48, 5)

import os
import threading
import numpy as np
import pandas as pd
from keras.models import load_model
from sklearn.preprocessing import MinMaxScaler

MODEL_PATH = os.path.join(os.path.dirname(__file__), "..", "lstm_model.h5")
FEATURES   = ["close", "pct_change", "vol_ma", "atr", "sentiment"]  # 5
SEQ_LEN    = 48                                                    # 48 step

_model      = None
_model_lock = threading.Lock()

def _get_model():
    global _model
    with _model_lock:
        if _model is None:
            _model = load_model(MODEL_PATH, compile=False)
    return _model


def predict_with_model(df: pd.DataFrame) -> float:
    """Ritorna il prezzo ´close´ previsto usando le ultime 48 righe."""
    missing = [c for c in FEATURES if c not in df.columns]
    if missing:
        raise ValueError(f"Mancano colonne per la previsione: {missing}")

    window = df[FEATURES].dropna().tail(SEQ_LEN)
    if len(window) < SEQ_LEN:
        raise ValueError(f"Servono almeno {SEQ_LEN} righe complete di dati.")

    scaler  = MinMaxScaler().fit(window)
    seq     = scaler.transform(window).reshape(1, SEQ_LEN, len(FEATURES))

    model   = _get_model()
    pred_sc = float(model.predict(seq, verbose=0)[0, 0])

    close_scaler = MinMaxScaler().fit(df[["close"]].dropna().tail(SEQ_LEN))
    pred_price   = float(close_scaler.inverse_transform([[pred_sc]])[0, 0])
    return pred_price
